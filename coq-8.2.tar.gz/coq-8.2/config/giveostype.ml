print_string Sys.os_type;;
